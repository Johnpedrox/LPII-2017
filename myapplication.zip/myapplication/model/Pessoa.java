package com.example.alunos.myapplication.model;

/**
 * Created by alunos on 13/09/17.
 */

public class Pessoa {
    private String nome;
    private String telefone;
    private int idade;

    public Pessoa(String nome, String telefone, int idade){
        this.nome = nome;
        this.telefone = telefone;
        this.idade = idade;
    }
    public String getNome(){
        return nome;
    }
    public String setNome(String nome){
        this.nome = nome;
    }
    public String getTelefone(){
        return telefone;
    }
    public String setTelefone(String telefone){
        this.telefone = telefone;
    }
    public String getIdade(){
        return idade;
    }
    public String setIdade(int idade){
        this.idade = idade;
    }
}