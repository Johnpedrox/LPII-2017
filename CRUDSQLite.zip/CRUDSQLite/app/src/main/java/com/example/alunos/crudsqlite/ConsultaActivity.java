package com.example.alunos.crudsqlite;

import android.app.Activity;

/**
 * Created by alunos on 20/09/17.
 */

public class ConsultaActivity extends Activity {
}
