package com.example.alunos.mapmarker;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button btnShowLocation;
    Button btnShowOnMap;
    TextView txtL1;
    TextView txtL2;

    private static final int REQUEST_CODE_PERMISSION = 2;
    String mPermission = Manifest.permission.ACCESS_FINE_LOCATION;
    GPSTracker gps;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        try{
            if (ActivityCompat.checkSelfPermission(this, mPermission)
                    != PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(this, new String[]{mPermission}, REQUEST_CODE_PERMISSION);
            }
        } catch (Exception e){
            e.printStackTrace();
        }

        btnShowLocation = (Button) findViewById(R.id.btnShowLocation);
        btnShowOnMap = (Button) findViewById(R.id.btnShowOnMap);
        txtL1 = (TextView) findViewById(R.id.txtL1);
        txtL2 = (TextView) findViewById(R.id.txtL1);

        btnShowLocation.setOnClickListener(new View.OnClickListener() {
            public  void onClick (View view){
                Intent it = new Intent(MainActivity.this, MapsActivity.class);
                startActivity(it);
            }
        });

        btnShowLocation .setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                gps = new GPSTracker(MainActivity.this);
                if (gps.canGetLocation()) {
                    double latitude = gps.getLatitude();
                    double longitude = gps.getLongitude();

                    txtL1.setText(String.valueOf(latitude));
                    txtL2.setText(String.valueOf(longitude));
                } else {
                    txtL1.setText(String.valueOf("Não disponível"));
                    txtL2.setText(String.valueOf("Não disponível"));
                    gps.showSettingsAlert();
                }
            }
        });
    }
}



